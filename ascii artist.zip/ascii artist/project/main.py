import os
from concurrent.futures import ThreadPoolExecutor
from alive_progress import alive_bar
from moviepy.editor import VideoFileClip

from ascii_art_maker import convert_img_to_ascii_art
from extract_frames import extract_frames_from_video
from create_video import create_and_save_video
from symbols import make_ASCII_list


while True:
    valid = True
    file_path = input("Путь до файла, который нужно преобразовать в ASCII art: ").strip('\"')
    if not (file_path.endswith(('.jpg', '.png', '.mp4'))):
        print ("\033[A" + " " * 190 + "\033[A")
        print("Неверный формат файла. Допустимые форматы: jpg, png, mp4")
        valid = False
        continue
    if not os.path.exists(file_path):
        print ("\033[A" + " " * 190 + "\033[A")
        print("Данного пути нет на Вашем компьютере")
        valid = False
    if (valid):
        break
RESULT_HEIGHT = abs(int(input("Требуемое количество символов по вертикали: ")))
symbols = input("Символы, из которых будет создаваться арт (оставьте поле "
                "пустым, чтобы использовать символы по умолчанию): ")

file_directory_name, file = os.path.split(os.path.abspath(file_path))
file_name, file_format = file.split('.')
result_without_audio_path = os.path.join(file_directory_name, f"{file_name}_ascii_art_without_audio.{file_format}")
result_path = os.path.join(file_directory_name, f"{file_name}_ascii_art.{file_format}")


CURRENT_DIR = os.getcwd()
frames_dir = os.path.join(CURRENT_DIR, "frames")
result_frames_dir = os.path.join(CURRENT_DIR, "result_frames")

symbols, is_RGB = make_ASCII_list(symbols)


def process_image():
    print("Обработка картирнки началась")
    with alive_bar(RESULT_HEIGHT, title="Преобразование картинки  ") as bar:
        result_img = convert_img_to_ascii_art(file_path, RESULT_HEIGHT, symbols, is_RGB, bar)
    result_img.save(result_path)


def process_video():
    print(f"Обработка видео началась")
    frames_count, fps = extract_frames_from_video(file_path, frames_dir)
    frames_per_group = frames_count // os.cpu_count()

    frame_groups = [range(i * frames_per_group, min((i + 1) * frames_per_group, frames_count)) for i in range((frames_count + frames_per_group - 1) // frames_per_group)]
    with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
        with alive_bar(frames_count, title="Преобразование видео  ") as bar:
            for _ in executor.map(lambda group: process_frame_group(group, frames_dir, result_frames_dir, symbols, is_RGB, RESULT_HEIGHT, bar), frame_groups):
                pass

    print ("\033[A" + " " * 190 + "\033[A")
    print(f"\033[F", end='')

    create_and_save_video(result_frames_dir, result_without_audio_path, "frame", "png", 25)

    for dir in [frames_dir, result_frames_dir]:
        for filename in os.listdir(dir):
            remove_file_path = os.path.join(dir, filename)
            os.unlink(remove_file_path)

    original_audio = VideoFileClip(file_path, verbose=False).audio
    result_without_audio = VideoFileClip(result_without_audio_path, verbose=False)
    result = result_without_audio.set_audio(original_audio)
    result.write_videofile(result_path, audio_codec='aac', verbose=False, logger=None)

    os.remove(result_without_audio_path)


def process_frame_group(frame_group, frames_dir, result_frames_dir, symbols, is_RGB, result_height, bar):
    for i in frame_group:
        bar()
        frame_path = os.path.join(frames_dir, f"frame_{i}.png")
        result_frame = convert_img_to_ascii_art(frame_path, result_height, symbols, is_RGB)
        result_frame_path = os.path.join(result_frames_dir, f"frame_{i}.png")
        result_frame.save(result_frame_path)


print()
if file_format == 'jpg' or file_format == 'png':
    process_image()
else:
    process_video()

print(f"\nРезультат сохранен в папку с исходником в файле {file_name}_ascii_art.{file_format}")
