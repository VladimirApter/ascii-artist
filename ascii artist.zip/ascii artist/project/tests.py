import unittest
from sort_ASCII import generate_sorted_ascii_list


class TestGenerateSortedAsciiList(unittest.TestCase):
    def test_one_symbol(self):
        self.assertEqual(['a'], generate_sorted_ascii_list('a'))

    def test_same_symbols(self):
        self.assertEqual(['a'], generate_sorted_ascii_list('aaaa'))

    def test_simple_symbols(self):
        self.assertEqual(['.', '+', 'a', '&'], generate_sorted_ascii_list('&+.a'))

    def test_chinese_symbols(self):
        self.assertEqual(['乁', '乀', '乍', '乂', '乑', '乘', '㒿'], generate_sorted_ascii_list('㒿乀乑乂乘乁乍'))


if __name__ == '__main__':
    unittest.main()
